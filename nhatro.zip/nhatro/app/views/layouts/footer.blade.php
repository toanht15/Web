<hr>
<!-- <div class="container">
	<div class="navbar navbar-bottom"> -->
	<!-- <div class="footer"> -->
	<div class="container">
	<footer>
		<p class="text-muted">
			<ul class="list-inline">
			<li>Nhatro.com - &copy {{ date('Y')}}</li>
	          <li><a href="/about">Về chúng tôi</a></li>
	          <li><a href="/contact">Liên hệ</a></li>
	        </ul>
	    <p>
	</footer>
	</div>
<!-- </div> -->