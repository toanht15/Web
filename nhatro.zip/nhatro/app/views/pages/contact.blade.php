@extends('layouts.default')
@section('content')

<div class="container">
	<div class="panel panel-info">
		<div class="panel-heading">
			<h5>Lien he</h5>
		</div>
	</div>
	<div class="jumbotron">
		<p>
		<ul>
		    <li>TEL: 0123456789</li>
		    <li>Address: HUST - D9 Building</li>
		</ul>
		</p>
	</div>
</div>
@stop