@extends('layouts.default')
@section('content')

<div class="container">
<div class="panel panel-info">
	<div class="panel-heading">
		<h5>About Us: HEDSPI K56 C</h5>
	</div>
</div>
<div class="jumbotron">
<p>
	Group 8:
	<ul>
	    <li>Le Van Hien</li>
	    <li>Hoang The Toan</li>
	    <li>Nguyen Van Thuan</li>
	    <li>Bui Quoc Dat</li>
	</ul>
</p>
</div>
</div>
@stop